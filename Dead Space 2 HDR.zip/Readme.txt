1. Extract all files to the Dead Space 2 install directory.
2. Download and run NVIDIA Profile Inspector: https://github.com/Orbmu2k/nvidiaProfileInspector/releases/latest
3. Import the included "Treat DXVK as Native" file to the global profile.
4. Run the game.

Dead Space 2 should now start in HDR, with ReShade configured to 203 nits paper white, tone-mapping the image to 1000 nits.
The END key will bring up the ReShade UI if you need to adjust these values.

The PgDn/PgUp key should switch between the default "1000 nits" profile and "FXAA" profile.
The latter adds some FXAA anti-aliasing and contrast-adaptive sharpening, which can help improve the image quality *somewhat* - though the performance cost may be relatively high.

The ReShade Display Commander add-on is included and can be used to set a frame-rate limit if desired/required.
Use the END key to open the ReShade UI and navigate to the "DC" tab to make adjustments.
Most areas of the game run fine with high frame rates thanks to the MarkerPatch - though some physics objects in the elementary school level still bug out above 30 fps.

I recommend having the MarkerPatch apply a Large Address Aware (LAA) patch to the game's executable.
This can be enabled in the configuration file at `\plugins\MarkerPatch.ini`
If you are running the Steam version of the game, you may first need to run `deadspace2.exe` through Steamless for that to work.
https://github.com/atom0s/Steamless/releases/latest